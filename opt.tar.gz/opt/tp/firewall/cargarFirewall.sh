#!/bin/sh

iptables-restore < /opt/tp/firewall/firewall.conf
