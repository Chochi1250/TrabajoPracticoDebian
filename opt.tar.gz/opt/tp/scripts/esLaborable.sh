#!/bin/bash

esLaborable()
{

#Variables:

fecha=$1
feriados=("2023-01-01" "2023-03-24" "2023-04-02" "2023-05-01" "2023-05-25" "2023-06-20" "2023-07-09" "2023-08-17" "2023-10-12" "2023-12-08" "2023-12-25")
diaDeLaSemana=$(date -d "$fecha" +%u)
 
#Comprobar si la fecha es dentro del fin de semana

if [ $diaDeLaSemana -eq 6 ] || [ $diaDeLaSemana -eq 7 ]; then
	echo "la fecha ingresada: $fecha no es laborable, es un fin de semana"
	exit 1
fi

#Comprobar si es feriado o no
encontrado=false
i=0

while [ $i -lt ${#feriados[@]} ]; do
	if [ "$fecha" == "${feriados[i]}" ]; then
		encontrado=true
		break
	fi
	((i++))

done

if [ "$encontrado" == true ]; then
	echo "La fecha ingresada: $fecha no es laborable, es un feriado"
	return 1
else
	echo "La fecha ingresada: $fecha es laborable"
	return 0
fi




}
