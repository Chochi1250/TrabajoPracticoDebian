#!/bin/bash

#Verificar que ingrese en blanco

if [ $# -eq 0 ]; then
	echo "Error, no se ingresaron parametros"
	echo "El uso correcto es: Uso: $0 <nombreDelProceso>"
	exit 1
fi

#variable

proceso=$1

#Verificar si el proceso ingresado existe o no

if ! pgrep -x "$proceso" > /dev/null; then
	echo "El proceso ingresado no existe"
	exit 1
fi

#Verificar si el proceso esta o no en ejecucion

if pgrep -x "$proceso" > /dev/null; then
	echo "El proceso $proceso esta en ejecucion"
else
	echo "El proceso $proceso no esta en ejecucion, se le informara al root"
	
	asunto="Alerta, el proceso: $proceso no esta en ejecucion"
	cuerpo="El proceso $proceso no esta en ejecucion"

	echo "$cuerpo" | mutt -s -- root
fi



