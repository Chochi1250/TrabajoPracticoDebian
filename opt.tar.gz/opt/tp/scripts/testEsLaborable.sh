#!/bin/bash

source esLaborable.sh

esLaborable "2023-11-16"
esLaborable "2023-05-25"
esLaborable "2023-01-01"


